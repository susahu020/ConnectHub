import { Request, Response, NextFunction } from 'express';
import prisma from '../config/db';
import redis from '../config/redis';
import { AuthenticatedRequest } from '../middleware/auth.middleware';
import { invalidateRoleCache, getRolePermissions } from '../services/rbac.service';
import { emitDataUpdate } from '../utils/realtime';

// Collects roleId plus every role that (transitively) inherits from it, the
// same set invalidateRoleCache() walks in rbac.service.ts — a permission
// change on a parent role changes the *effective* permissions of every
// descendant role too, not just roleId itself.
const collectRoleAndDescendants = async (roleId: string): Promise<string[]> => {
  const ids = [roleId];
  const children = await prisma.customRole.findMany({ where: { parentId: roleId }, select: { id: true } });
  for (const child of children) {
    ids.push(...(await collectRoleAndDescendants(child.id)));
  }
  return ids;
};

// Pushes the freshly-recompiled permission set straight to every currently
// signed-in user affected by a role permission change — every user directly
// on this role, plus everyone on a role that inherits from it. Without this,
// updateRolePermissions only invalidated the server-side Redis cache; users
// already logged in kept acting on their stale, pre-change permission map
// (visible in the UI, and enforced by hasPermission()) until they happened
// to log out and back in.
const pushRolePermissionUpdatesToAffectedUsers = async (req: AuthenticatedRequest, roleId: string): Promise<void> => {
  const io = req.app.get('io');
  if (!io) return;

  const affectedRoleIds = await collectRoleAndDescendants(roleId);
  const affectedUsers = await prisma.user.findMany({
    where: { customRoleId: { in: affectedRoleIds } },
    select: { id: true, customRoleId: true },
  });
  if (affectedUsers.length === 0) return;

  // Compile each distinct role once (getRolePermissions is itself cached),
  // not once per user, since many users typically share a role.
  const permissionsByRole = new Map<string, Record<string, Record<string, boolean>>>();
  const roleNameById = new Map<string, string>();
  for (const affectedRoleId of new Set(affectedUsers.map((u) => u.customRoleId!))) {
    const [permissions, roleRecord] = await Promise.all([
      getRolePermissions(affectedRoleId),
      prisma.customRole.findUnique({ where: { id: affectedRoleId }, select: { name: true } }),
    ]);
    permissionsByRole.set(affectedRoleId, permissions);
    roleNameById.set(affectedRoleId, roleRecord?.name || '');
  }

  for (const user of affectedUsers) {
    io.to(`user:${user.id}`).emit('role_assignment_updated', {
      customRoleId: user.customRoleId,
      roleName: roleNameById.get(user.customRoleId!) || '',
      permissions: permissionsByRole.get(user.customRoleId!) || {},
    });
  }
};

/**
 * Get all custom roles.
 */
export const getRoles = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const roles = await prisma.customRole.findMany({
      include: {
        parent: { select: { id: true, name: true } },
        _count: { select: { users: true } },
      },
      orderBy: { name: 'asc' },
    });
    res.status(200).json(roles);
  } catch (error) {
    next(error);
  }
};

/**
 * Get role details and its permissions.
 */
export const getRoleDetails = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const role = await prisma.customRole.findUnique({
      where: { id },
      include: {
        parent: { select: { id: true, name: true } },
        permissions: true,
      },
    });

    if (!role) {
      res.status(404).json({ message: 'Role not found.' });
      return;
    }

    // `permissions` above is only the rows explicitly set ON this role —
    // it does not include values this role inherits from its parent chain.
    // `effectivePermissions` is the fully compiled module/action map (same
    // compiler `hasPermission()` uses at request time) so the client can
    // show what a role can *actually* do right now, and tell "explicitly
    // granted on this role" apart from "granted only via inheritance" —
    // see the note on updateRolePermissions for why that distinction matters.
    const effectivePermissions = await getRolePermissions(id);

    res.status(200).json({ ...role, effectivePermissions });
  } catch (error) {
    next(error);
  }
};

/**
 * Create a new custom role.
 */
export const createRole = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { name, description, parentId, duplicateFromRoleId } = req.body;

    if (!name || !name.trim()) {
      res.status(400).json({ message: 'Role name is required.' });
      return;
    }

    // Check duplicate name
    const existing = await prisma.customRole.findUnique({ where: { name } });
    if (existing) {
      res.status(400).json({ message: 'Role name already exists.' });
      return;
    }

    // Create the role
    const role = await prisma.customRole.create({
      data: {
        name,
        description,
        parentId: parentId || null,
      },
    });

    // If duplicateFromRoleId is specified, copy permissions
    if (duplicateFromRoleId) {
      const sourcePermissions = await prisma.customPermission.findMany({
        where: { roleId: duplicateFromRoleId },
      });

      if (sourcePermissions.length > 0) {
        await prisma.customPermission.createMany({
          data: sourcePermissions.map((sp) => ({
            roleId: role.id,
            module: sp.module,
            action: sp.action,
            isEnabled: sp.isEnabled,
          })),
        });
      }
    }

    // Audit Log
    await prisma.auditLog.create({
      data: {
        userId: req.user?.id,
        action: 'CREATE_ROLE',
        details: `Created custom role "${name}"`,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'] || null,
      },
    });

    res.status(201).json(role);

    emitDataUpdate(req, 'roles');
  } catch (error) {
    next(error);
  }
};

/**
 * Update the permission matrix for a specific role.
 */
export const updateRolePermissions = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id: roleId } = req.params;
    // Array of { module, action, isEnabled }. IMPORTANT: this should only
    // contain cells the caller wants to explicitly set (override) on THIS
    // role — every entry becomes a real CustomPermission row via the upsert
    // below. Submitting the full MODULES x ACTIONS cross-product (including
    // entries the admin never touched) would create an explicit `false` row
    // for everything this role currently gets only via inheritance from its
    // parent, silently wiping that inheritance out — because getRolePermissions()
    // only falls back to the parent's value when the child has NO row at all
    // for that module/action, explicit `false` included. See the frontend's
    // permission-matrix editor (admin/page.tsx), which now submits only the
    // cells the admin actually interacted with, plus any pre-existing
    // explicit rows — never the full grid.
    const { permissions } = req.body;

    if (!Array.isArray(permissions)) {
      res.status(400).json({ message: 'Permissions array is required.' });
      return;
    }

    const role = await prisma.customRole.findUnique({ where: { id: roleId } });
    if (!role) {
      res.status(404).json({ message: 'Role not found.' });
      return;
    }

    // Upsert permissions
    await prisma.$transaction(
      permissions.map((p) =>
        prisma.customPermission.upsert({
          where: {
            roleId_module_action: {
              roleId,
              module: p.module,
              action: p.action,
            },
          },
          update: { isEnabled: p.isEnabled },
          create: {
            roleId,
            module: p.module,
            action: p.action,
            isEnabled: p.isEnabled,
          },
        })
      )
    );

    // Invalidate Redis permissions cache for this role and its descendants
    await invalidateRoleCache(roleId);

    // Audit Log
    await prisma.auditLog.create({
      data: {
        userId: req.user?.id,
        action: 'UPDATE_ROLE_PERMISSIONS',
        details: `Updated permission matrix for role "${role.name}"`,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'] || null,
      },
    });

    emitDataUpdate(req, 'roles');
    await pushRolePermissionUpdatesToAffectedUsers(req, roleId);

    res.status(200).json({ message: 'Role permissions updated successfully.' });
  } catch (error) {
    next(error);
  }
};

/**
 * Duplicate an existing role.
 */
export const duplicateRole = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const { newName, description } = req.body;

    if (!newName || !newName.trim()) {
      res.status(400).json({ message: 'New role name is required.' });
      return;
    }

    const sourceRole = await prisma.customRole.findUnique({
      where: { id },
      include: { permissions: true },
    });

    if (!sourceRole) {
      res.status(404).json({ message: 'Source role not found.' });
      return;
    }

    const existing = await prisma.customRole.findUnique({ where: { name: newName } });
    if (existing) {
      res.status(400).json({ message: 'Role name already exists.' });
      return;
    }

    // Create target role duplicating parentId
    const duplicatedRole = await prisma.customRole.create({
      data: {
        name: newName,
        description: description || `Duplicate of ${sourceRole.name}`,
        parentId: sourceRole.parentId,
      },
    });

    // Copy permissions
    if (sourceRole.permissions.length > 0) {
      await prisma.customPermission.createMany({
        data: sourceRole.permissions.map((sp) => ({
          roleId: duplicatedRole.id,
          module: sp.module,
          action: sp.action,
          isEnabled: sp.isEnabled,
        })),
      });
    }

    // Audit Log
    await prisma.auditLog.create({
      data: {
        userId: req.user?.id,
        action: 'DUPLICATE_ROLE',
        details: `Duplicated role "${sourceRole.name}" to "${newName}"`,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'] || null,
      },
    });

    res.status(201).json(duplicatedRole);

    emitDataUpdate(req, 'roles');
  } catch (error) {
    next(error);
  }
};

/**
 * Delete a custom role.
 */
export const deleteRole = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;

    const role = await prisma.customRole.findUnique({
      where: { id },
      include: { _count: { select: { users: true } } },
    });

    if (!role) {
      res.status(404).json({ message: 'Role not found.' });
      return;
    }

    if (role._count.users > 0) {
      res.status(400).json({ message: 'Cannot delete a role that has active users assigned.' });
      return;
    }

    // Clean cache
    await invalidateRoleCache(id);

    await prisma.customRole.delete({ where: { id } });

    // Audit Log
    await prisma.auditLog.create({
      data: {
        userId: req.user?.id,
        action: 'DELETE_ROLE',
        details: `Deleted custom role "${role.name}"`,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'] || null,
      },
    });

    res.status(200).json({ message: 'Role deleted successfully.' });

    emitDataUpdate(req, 'roles');
  } catch (error) {
    next(error);
  }
};

/**
 * Assign a custom role to a user.
 */
export const assignRole = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { userId } = req.params;
    const { roleId, expiresAt } = req.body; // customRoleId; expiresAt is optional (time-bound elevation)

    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      res.status(404).json({ message: 'User not found.' });
      return;
    }

    // roleId is nullable — this doubles as the unassign path (revert to
    // base permissions only), which previously had no way to be reached
    // from this endpoint at all.
    let role: { name: string } | null = null;
    if (roleId) {
      role = await prisma.customRole.findUnique({ where: { id: roleId }, select: { name: true } });
      if (!role) {
        res.status(404).json({ message: 'Custom role not found.' });
        return;
      }
    }

    let parsedExpiresAt: Date | null = null;
    if (roleId && expiresAt) {
      parsedExpiresAt = new Date(expiresAt);
      if (Number.isNaN(parsedExpiresAt.getTime())) {
        res.status(400).json({ message: 'expiresAt is not a valid date.' });
        return;
      }
      if (parsedExpiresAt <= new Date()) {
        res.status(400).json({ message: 'expiresAt must be in the future.' });
        return;
      }
    }

    // Only the granular RBAC role is updated here. This must NOT also set
    // the legacy `role` enum based on the custom role's name — a custom
    // role named e.g. "Admin" (for any unrelated reason) would otherwise
    // silently grant real admin-panel access to whoever it's assigned to.
    // The legacy system-access tier is changed exclusively through the
    // dedicated "System Access Role" controls (updateUserRole /
    // adminUpdateUser), which carry their own self- and last-admin guards.
    await prisma.user.update({
      where: { id: userId },
      data: { customRoleId: roleId || null, customRoleExpiresAt: parsedExpiresAt },
    });

    // Invalidate session cache in Redis to refresh permissions immediately
    if (roleId) {
      await redis.del(`permissions:role:${roleId}`);
    }

    // Audit Log
    await prisma.auditLog.create({
      data: {
        userId: req.user?.id,
        action: role ? 'ASSIGN_ROLE' : 'UNASSIGN_ROLE',
        details: role
          ? `Assigned custom role "${role.name}" to user ${user.email}${parsedExpiresAt ? ` until ${parsedExpiresAt.toISOString()}` : ''}`
          : `Removed custom role assignment from user ${user.email}`,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'] || null,
      },
    });

    // Refresh any admin screens currently listing users (e.g. the User
    // Management table showing each user's assigned role) — this mutation
    // was previously missing from the generic real-time broadcast that every
    // other user-affecting admin action already triggers.
    emitDataUpdate(req, 'users');

    // Push the change straight to the affected user's own active session(s)
    // so their permissions take effect immediately, without them needing to
    // refresh the page or log back in. The compiled permission map is sent
    // along so the client can update its local state directly rather than
    // making a follow-up round trip.
    const io = req.app.get('io');
    if (io) {
      const permissions = roleId ? await getRolePermissions(roleId) : {};
      io.to(`user:${userId}`).emit('role_assignment_updated', {
        customRoleId: roleId || null,
        roleName: role?.name || '',
        permissions,
      });
    }

    res.status(200).json({
      message: role ? `Role "${role.name}" successfully assigned.` : 'Custom role assignment removed.',
    });

  } catch (error) {
    next(error);
  }
};
