import { Response, NextFunction } from 'express';
import prisma from '../config/db';
import { AuthenticatedRequest } from '../middleware/auth.middleware';
import { logAudit } from '../utils/auditLog';
import { isAuthorizedApprover, isManagerOrAdmin, getVisibleUserIds } from '../services/approval.service';

// Real-time update helper via Socket.io
const emitHRUpdate = (req: any, type: string) => {
  const io = req.app.get('io');
  if (io) {
    io.emit('hr_update', { type });
  }
};

// ==========================================
// LEAVE MANAGEMENT
// ==========================================

export const getLeaves = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const role = req.user?.role!;
    // Admins see every request; Managers see their own plus their direct
    // reports' (not the whole company's — see getVisibleUserIds); Employees
    // see only their own. Mirrors the scope `isAuthorizedApprover` already
    // enforces on the approve/reject action for the same data.
    const visibleUserIds = await getVisibleUserIds(req.user?.id!, role);

    const leaves = await prisma.leaveRequest.findMany({
      where: visibleUserIds ? { userId: { in: visibleUserIds } } : undefined,
      include: {
        user: { select: { id: true, firstName: true, lastName: true, email: true, designation: true } },
        approvedBy: { select: { id: true, firstName: true, lastName: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    res.status(200).json(leaves);
  } catch (error) {
    next(error);
  }
};

export const requestLeave = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id!;
    const { leaveType, startDate, endDate, reason } = req.body;

    if (!leaveType || !startDate || !endDate || !reason) {
      res.status(400).json({ message: 'All fields (leaveType, startDate, endDate, reason) are required.' });
      return;
    }

    const start = new Date(startDate);
    const end = new Date(endDate);

    if (isNaN(start.getTime()) || isNaN(end.getTime()) || start > end) {
      res.status(400).json({ message: 'Invalid start or end date.' });
      return;
    }

    const leave = await prisma.leaveRequest.create({
      data: {
        userId,
        leaveType,
        startDate: start,
        endDate: end,
        reason,
        status: 'PENDING',
      },
    });

    // Trigger workflow automation engine on new leave request submission
    const { AutomationService } = require('../services/automation.service');
    const automationIo = req.app.get('io');
    AutomationService.trigger('LEAVE_REQUESTED', {
      requesterId: userId,
      leaveType,
    }, automationIo).catch((err: any) => console.error('[Automation] LEAVE_REQUESTED trigger failed:', err));

    emitHRUpdate(req, 'LEAVE');
    res.status(201).json(leave);
  } catch (error) {
    next(error);
  }
};

export const getLeaveBalances = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id!;
    const year = new Date().getFullYear();

    const defaultTypes = [
      { leaveType: 'ANNUAL', total: 12 },
      { leaveType: 'SICK', total: 8 },
      { leaveType: 'CASUAL', total: 6 },
      { leaveType: 'UNPAID', total: 30 },
    ];

    let balances = await prisma.leaveBalance.findMany({
      where: { userId, year },
    });

    if (balances.length === 0) {
      await prisma.leaveBalance.createMany({
        data: defaultTypes.map((t) => ({
          userId,
          year,
          leaveType: t.leaveType,
          total: t.total,
          used: 0,
        })),
      });

      balances = await prisma.leaveBalance.findMany({
        where: { userId, year },
      });
    }

    res.status(200).json(balances);
  } catch (error) {
    next(error);
  }
};

export const updateLeaveStatus = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const role = req.user?.role!;
    if (!isManagerOrAdmin(role)) {
      res.status(403).json({ message: 'Forbidden. Only managers and admins can approve leaves.' });
      return;
    }

    const { id } = req.params;
    const { status, managerNotes } = req.body;

    if (status !== 'APPROVED' && status !== 'REJECTED') {
      res.status(400).json({ message: 'Status must be APPROVED or REJECTED.' });
      return;
    }

    const leaveRequest = await prisma.leaveRequest.findUnique({
      where: { id },
    });

    if (!leaveRequest) {
      res.status(404).json({ message: 'Leave request not found.' });
      return;
    }

    if (leaveRequest.status !== 'PENDING') {
      res.status(400).json({ message: 'Leave request is already processed.' });
      return;
    }

    if (leaveRequest.userId === req.user?.id) {
      res.status(403).json({ message: 'You cannot approve or reject your own leave request. Ask another manager or admin to review it.' });
      return;
    }

    if (!(await isAuthorizedApprover(req.user!.id, role, leaveRequest.userId))) {
      res.status(403).json({ message: "Forbidden. Only this employee's reporting manager or an admin can approve or reject this leave request." });
      return;
    }

    if (status === 'APPROVED') {
      // Calculate leave days
      const diffTime = Math.abs(leaveRequest.endDate.getTime() - leaveRequest.startDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
      const year = leaveRequest.startDate.getFullYear();

      // Find or create balance
      let balance = await prisma.leaveBalance.findUnique({
        where: {
          userId_leaveType_year: {
            userId: leaveRequest.userId,
            leaveType: leaveRequest.leaveType,
            year,
          },
        },
      });

      if (!balance) {
        // Create a default balance if none exists
        balance = await prisma.leaveBalance.create({
          data: {
            userId: leaveRequest.userId,
            leaveType: leaveRequest.leaveType,
            year,
            total: leaveRequest.leaveType === 'UNPAID' ? 30 : leaveRequest.leaveType === 'ANNUAL' ? 12 : 8,
            used: 0,
          },
        });
      }

      // Nothing anywhere — not this endpoint, not requestLeave, not the
      // frontend — previously checked this request against what's actually
      // left, so approving enough leave requests could push `used` past
      // `total` with no warning to the approving manager (who also has no
      // visibility into the requester's balance in the approval UI). That
      // silently defeats the entire point of tracking a balance.
      if (balance.used + diffDays > balance.total) {
        res.status(400).json({
          message: `Cannot approve: this would use ${balance.used + diffDays} of ${balance.total} ${leaveRequest.leaveType.toLowerCase()} days allocated for ${year} (${balance.total - balance.used} remaining). Reject it, or ask the employee to adjust the date range.`,
        });
        return;
      }

      await prisma.leaveBalance.update({
        where: { id: balance.id },
        data: { used: balance.used + diffDays },
      });
    }

    const updatedLeave = await prisma.leaveRequest.update({
      where: { id },
      data: {
        status,
        approvedById: req.user?.id!,
        managerNotes: managerNotes || null,
      },
    });

    emitHRUpdate(req, 'LEAVE');
    logAudit(req, 'LEAVE_REQUEST_' + status, `${status === 'APPROVED' ? 'Approved' : 'Rejected'} leave request ${id} for user ${leaveRequest.userId} (${leaveRequest.leaveType}, ${leaveRequest.startDate.toDateString()} - ${leaveRequest.endDate.toDateString()}).`);
    res.status(200).json(updatedLeave);
  } catch (error) {
    next(error);
  }
};

// ==========================================
// ATTENDANCE MANAGEMENT
// ==========================================

export const getTodayStatus = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id!;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const attendance = await prisma.attendance.findFirst({
      where: { userId, date: today },
      include: { breaks: true },
    });

    res.status(200).json(attendance);
  } catch (error) {
    next(error);
  }
};

export const clockIn = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id!;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Check if already clocked in today
    const existing = await prisma.attendance.findFirst({
      where: { userId, date: today },
    });

    if (existing) {
      res.status(400).json({ message: 'Already clocked in for today.' });
      return;
    }

    const { location, notes } = req.body;

    const log = await prisma.attendance.create({
      data: {
        userId,
        date: today,
        clockIn: new Date(),
        status: 'PRESENT',
        ipAddress: req.ip || null,
        location: location || null,
        notes: notes || null,
      },
    });

    emitHRUpdate(req, 'ATTENDANCE');
    res.status(201).json(log);
  } catch (error) {
    next(error);
  }
};

export const clockOut = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id!;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const attendance = await prisma.attendance.findFirst({
      where: { userId, date: today, clockOut: null },
    });

    if (!attendance) {
      res.status(400).json({ message: 'No active clock-in session found for today.' });
      return;
    }

    const { notes } = req.body;

    // Check if there is an open break, end it
    const openBreak = await prisma.attendanceBreak.findFirst({
      where: { attendanceId: attendance.id, endTime: null },
    });

    if (openBreak) {
      await prisma.attendanceBreak.update({
        where: { id: openBreak.id },
        data: { endTime: new Date() },
      });
    }

    const log = await prisma.attendance.update({
      where: { id: attendance.id },
      data: {
        clockOut: new Date(),
        notes: notes ? `${attendance.notes || ''}\nClockOut: ${notes}`.trim() : attendance.notes,
      },
      include: { breaks: true },
    });

    emitHRUpdate(req, 'ATTENDANCE');
    res.status(200).json(log);
  } catch (error) {
    next(error);
  }
};

export const startBreak = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id!;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const attendance = await prisma.attendance.findFirst({
      where: { userId, date: today, clockOut: null },
    });

    if (!attendance) {
      res.status(400).json({ message: 'Must be clocked in to take a break.' });
      return;
    }

    const existingBreak = await prisma.attendanceBreak.findFirst({
      where: { attendanceId: attendance.id, endTime: null },
    });

    if (existingBreak) {
      res.status(400).json({ message: 'Break is already in progress.' });
      return;
    }

    const attendanceBreak = await prisma.attendanceBreak.create({
      data: {
        attendanceId: attendance.id,
        startTime: new Date(),
      },
    });

    emitHRUpdate(req, 'ATTENDANCE');
    res.status(201).json(attendanceBreak);
  } catch (error) {
    next(error);
  }
};

export const endBreak = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id!;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const attendance = await prisma.attendance.findFirst({
      where: { userId, date: today, clockOut: null },
    });

    if (!attendance) {
      res.status(400).json({ message: 'No active clock-in session.' });
      return;
    }

    const activeBreak = await prisma.attendanceBreak.findFirst({
      where: { attendanceId: attendance.id, endTime: null },
    });

    if (!activeBreak) {
      res.status(400).json({ message: 'No active break found.' });
      return;
    }

    const endedBreak = await prisma.attendanceBreak.update({
      where: { id: activeBreak.id },
      data: { endTime: new Date() },
    });

    emitHRUpdate(req, 'ATTENDANCE');
    res.status(200).json(endedBreak);
  } catch (error) {
    next(error);
  }
};

export const getAttendanceLogs = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const role = req.user?.role!;
    const { userId: queryUserId, all } = req.query;
    const visibleUserIds = await getVisibleUserIds(req.user?.id!, role);
    let logs;

    if (all === 'true' && isManagerOrAdmin(role)) {
      // "All" means all records the caller may see — every user in the
      // company for an Admin, or the caller's own + their direct reports'
      // for a Manager (not every employee regardless of who they report to).
      logs = await prisma.attendance.findMany({
        where: visibleUserIds ? { userId: { in: visibleUserIds } } : undefined,
        include: {
          user: { select: { id: true, firstName: true, lastName: true, email: true, designation: true } },
          breaks: true,
        },
        orderBy: { date: 'desc' },
      });
    } else {
      // A single-user lookup via ?userId= is only honored if that user is
      // actually within the caller's visibility (self, or — for a Manager —
      // a direct report). Otherwise it silently falls back to "my own",
      // rather than letting a Manager pull an arbitrary employee's
      // attendance by guessing/enumerating their userId.
      const requestedId = queryUserId ? String(queryUserId) : req.user?.id!;
      const targetUserId =
        !visibleUserIds || visibleUserIds.includes(requestedId) ? requestedId : req.user?.id!;
      logs = await prisma.attendance.findMany({
        where: { userId: targetUserId },
        include: { breaks: true },
        orderBy: { date: 'desc' },
      });
    }

    res.status(200).json(logs);
  } catch (error) {
    next(error);
  }
};

// ==========================================
// HOLIDAY MANAGEMENT
// ==========================================

export const getHolidays = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const holidays = await prisma.holiday.findMany({
      orderBy: { date: 'asc' },
    });
    res.status(200).json(holidays);
  } catch (error) {
    next(error);
  }
};

export const createHoliday = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!isManagerOrAdmin(req.user?.role!)) {
      res.status(403).json({ message: 'Forbidden. Only managers and admins can add holidays.' });
      return;
    }

    const { name, date, description, isMandatory } = req.body;
    if (!name || !date) {
      res.status(400).json({ message: 'Name and date are required.' });
      return;
    }

    const holidayDate = new Date(date);
    if (isNaN(holidayDate.getTime())) {
      res.status(400).json({ message: 'Invalid holiday date.' });
      return;
    }

    const existing = await prisma.holiday.findUnique({
      where: { date: holidayDate },
    });

    if (existing) {
      res.status(400).json({ message: 'A holiday on this date already exists.' });
      return;
    }

    const holiday = await prisma.holiday.create({
      data: {
        name,
        date: holidayDate,
        description: description || null,
        isMandatory: isMandatory !== undefined ? isMandatory : true,
      },
    });

    emitHRUpdate(req, 'HOLIDAY');
    res.status(201).json(holiday);
  } catch (error) {
    next(error);
  }
};

export const deleteHoliday = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!isManagerOrAdmin(req.user?.role!)) {
      res.status(403).json({ message: 'Forbidden. Only managers and admins can delete holidays.' });
      return;
    }

    const { id } = req.params;

    await prisma.holiday.delete({
      where: { id },
    });

    emitHRUpdate(req, 'HOLIDAY');
    res.status(200).json({ message: 'Holiday deleted successfully.' });
  } catch (error) {
    next(error);
  }
};

// ==========================================
// EXPENSE CLAIMS MANAGEMENT
// ==========================================

export const getExpenseClaims = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const role = req.user?.role!;
    const visibleUserIds = await getVisibleUserIds(req.user?.id!, role);

    const claims = await prisma.expenseClaim.findMany({
      where: visibleUserIds ? { userId: { in: visibleUserIds } } : undefined,
      include: {
        user: { select: { id: true, firstName: true, lastName: true, email: true, designation: true } },
        approvedBy: { select: { id: true, firstName: true, lastName: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    res.status(200).json(claims);
  } catch (error) {
    next(error);
  }
};

export const createExpenseClaim = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id!;
    const { title, category, amount, currency, description, receiptUrl } = req.body;

    if (!title || !category || amount === undefined) {
      res.status(400).json({ message: 'Title, category, and amount are required.' });
      return;
    }

    const claim = await prisma.expenseClaim.create({
      data: {
        userId,
        title,
        category,
        amount: parseFloat(amount),
        currency: currency || 'USD',
        description: description || null,
        receiptUrl: receiptUrl || null,
        status: 'PENDING',
      },
    });

    emitHRUpdate(req, 'EXPENSE');
    res.status(201).json(claim);
  } catch (error) {
    next(error);
  }
};

export const updateExpenseStatus = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!isManagerOrAdmin(req.user?.role!)) {
      res.status(403).json({ message: 'Forbidden. Only managers and admins can approve expenses.' });
      return;
    }

    const { id } = req.params;
    const { status, managerNotes } = req.body;

    if (status !== 'APPROVED' && status !== 'REJECTED') {
      res.status(400).json({ message: 'Status must be APPROVED or REJECTED.' });
      return;
    }

    const claim = await prisma.expenseClaim.findUnique({ where: { id } });
    if (!claim) {
      res.status(404).json({ message: 'Expense claim not found.' });
      return;
    }

    if (claim.userId === req.user?.id) {
      res.status(403).json({ message: 'You cannot approve or reject your own expense claim. Ask another manager or admin to review it.' });
      return;
    }

    if (!(await isAuthorizedApprover(req.user!.id, req.user?.role!, claim.userId))) {
      res.status(403).json({ message: "Forbidden. Only this employee's reporting manager or an admin can approve or reject this expense claim." });
      return;
    }

    const updatedClaim = await prisma.expenseClaim.update({
      where: { id },
      data: {
        status,
        approvedById: req.user?.id!,
        managerNotes: managerNotes || null,
      },
    });

    emitHRUpdate(req, 'EXPENSE');
    logAudit(req, 'EXPENSE_CLAIM_' + status, `${status === 'APPROVED' ? 'Approved' : 'Rejected'} expense claim ${id} for user ${claim.userId} (amount: ${claim.amount}).`);
    res.status(200).json(updatedClaim);
  } catch (error) {
    next(error);
  }
};

// ==========================================
// PAYSLIP MANAGEMENT
// ==========================================

export const getPayslips = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const role = req.user?.role!;
    let payslips;

    // Payslips carry salary figures — unlike leave/attendance, this isn't
    // shared team-visibility territory. Only Admins (payroll/HR) see everyone's;
    // Managers see their own payslips only, same as any other employee.
    if (role === 'ADMIN') {
      payslips = await prisma.payslip.findMany({
        include: {
          user: { select: { id: true, firstName: true, lastName: true, email: true, designation: true } },
          generatedBy: { select: { id: true, firstName: true, lastName: true } },
        },
        orderBy: [{ year: 'desc' }, { month: 'desc' }],
      });
    } else {
      payslips = await prisma.payslip.findMany({
        where: { userId: req.user?.id! },
        include: {
          generatedBy: { select: { id: true, firstName: true, lastName: true } },
        },
        orderBy: [{ year: 'desc' }, { month: 'desc' }],
      });
    }

    res.status(200).json(payslips);
  } catch (error) {
    next(error);
  }
};

export const generatePayslip = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (req.user?.role !== 'ADMIN') {
      res.status(403).json({ message: 'Forbidden. Only Admins can generate payslips.' });
      return;
    }

    const { employeeId, month, year, basicSalary, allowances, deductions, notes, fileUrl } = req.body;

    if (!employeeId || month === undefined || year === undefined || basicSalary === undefined) {
      res.status(400).json({ message: 'employeeId, month, year, and basicSalary are required.' });
      return;
    }

    const employee = await prisma.user.findUnique({ where: { id: employeeId } });
    if (!employee) {
      res.status(404).json({ message: 'Employee user not found.' });
      return;
    }

    if (employeeId === req.user?.id) {
      res.status(403).json({ message: 'You cannot generate your own payslip. Ask another admin to process this for you.' });
      return;
    }

    const basic = parseFloat(basicSalary);
    const allow = allowances ? parseFloat(allowances) : 0;
    const deduct = deductions ? parseFloat(deductions) : 0;
    const netSalary = basic + allow - deduct;

    const payslip = await prisma.payslip.create({
      data: {
        userId: employeeId,
        month: parseInt(month),
        year: parseInt(year),
        basicSalary: basic,
        allowances: allow,
        deductions: deduct,
        netSalary,
        status: 'UNPAID',
        generatedById: req.user?.id!,
        notes: notes || null,
        fileUrl: fileUrl || null,
      },
    });

    emitHRUpdate(req, 'PAYSLIP');
    logAudit(req, 'PAYSLIP_GENERATED', `Generated ${month}/${year} payslip for user ${employeeId}: basic ${basic}, allowances ${allow}, deductions ${deduct}, net ${netSalary}.`);
    res.status(201).json(payslip);
  } catch (error) {
    next(error);
  }
};

export const updatePayslipStatus = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (req.user?.role !== 'ADMIN') {
      res.status(403).json({ message: 'Forbidden. Only Admins can update payslip status.' });
      return;
    }

    const { id } = req.params;
    const { status } = req.body;

    if (status !== 'PAID' && status !== 'UNPAID' && status !== 'DRAFT') {
      res.status(400).json({ message: 'Invalid payslip status.' });
      return;
    }

    const updated = await prisma.payslip.update({
      where: { id },
      data: { status },
    });

    emitHRUpdate(req, 'PAYSLIP');
    logAudit(req, 'PAYSLIP_STATUS_UPDATED', `Set payslip ${id} (user ${updated.userId}) status to ${status}.`);
    res.status(200).json(updated);
  } catch (error) {
    next(error);
  }
};

// ==========================================
// SHIFT MANAGEMENT
// ==========================================

export const getShifts = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const shifts = await prisma.shift.findMany({
      orderBy: { name: 'asc' },
    });
    res.status(200).json(shifts);
  } catch (error) {
    next(error);
  }
};

export const createShift = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!isManagerOrAdmin(req.user?.role!)) {
      res.status(403).json({ message: 'Forbidden. Only managers and admins can define shifts.' });
      return;
    }

    const { name, startTime, endTime, color, description } = req.body;
    if (!name || !startTime || !endTime) {
      res.status(400).json({ message: 'Name, startTime, and endTime are required.' });
      return;
    }

    const shift = await prisma.shift.create({
      data: { name, startTime, endTime, color, description },
    });

    emitHRUpdate(req, 'SHIFT');
    res.status(201).json(shift);
  } catch (error) {
    next(error);
  }
};

export const getShiftAssignments = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const assignments = await prisma.shiftAssignment.findMany({
      include: {
        user: { select: { id: true, firstName: true, lastName: true, email: true, designation: true } },
        shift: true,
      },
      orderBy: { startDate: 'asc' },
    });

    res.status(200).json(assignments);
  } catch (error) {
    next(error);
  }
};

export const assignShift = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!isManagerOrAdmin(req.user?.role!)) {
      res.status(403).json({ message: 'Forbidden. Only managers and admins can assign shifts.' });
      return;
    }

    const { employeeId, shiftId, startDate, endDate } = req.body;
    if (!employeeId || !shiftId || !startDate || !endDate) {
      res.status(400).json({ message: 'employeeId, shiftId, startDate, and endDate are required.' });
      return;
    }

    const assignment = await prisma.shiftAssignment.create({
      data: {
        userId: employeeId,
        shiftId,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
      },
      include: {
        shift: true,
        user: { select: { id: true, firstName: true, lastName: true } },
      },
    });

    emitHRUpdate(req, 'SHIFT');
    res.status(201).json(assignment);
  } catch (error) {
    next(error);
  }
};

export const createSwapRequest = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id!;
    const { requesterAssignmentId, assigneeId, assigneeAssignmentId } = req.body;

    if (!requesterAssignmentId || !assigneeId || !assigneeAssignmentId) {
      res.status(400).json({ message: 'requesterAssignmentId, assigneeId, and assigneeAssignmentId are required.' });
      return;
    }

    if (assigneeId === userId) {
      res.status(400).json({ message: 'You cannot request a shift swap with yourself.' });
      return;
    }

    const [requesterAssignment, assigneeAssignment] = await Promise.all([
      prisma.shiftAssignment.findUnique({ where: { id: requesterAssignmentId } }),
      prisma.shiftAssignment.findUnique({ where: { id: assigneeAssignmentId } }),
    ]);

    if (!requesterAssignment || !assigneeAssignment) {
      res.status(404).json({ message: 'One or both shift assignments could not be found.' });
      return;
    }

    // The client is trusted to only ever offer the user's own assignments and the
    // chosen teammate's assignments in its dropdowns, but that's a UI convenience,
    // not enforcement — verify it server-side so a request can't be built to swap
    // shifts that don't actually belong to the stated requester/assignee.
    if (requesterAssignment.userId !== userId) {
      res.status(403).json({ message: 'You can only offer your own shift assignment in a swap request.' });
      return;
    }
    if (assigneeAssignment.userId !== assigneeId) {
      res.status(400).json({ message: "The selected shift assignment does not belong to the chosen teammate." });
      return;
    }

    const swap = await prisma.shiftSwapRequest.create({
      data: {
        requesterId: userId,
        assigneeId,
        requesterAssignmentId,
        assigneeAssignmentId,
        status: 'PENDING',
      },
    });

    emitHRUpdate(req, 'SHIFT');
    res.status(201).json(swap);
  } catch (error) {
    next(error);
  }
};

export const getSwapRequests = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const role = req.user?.role!;
    const visibleUserIds = await getVisibleUserIds(req.user?.id!, role);
    let swaps;

    if (!visibleUserIds) {
      swaps = await prisma.shiftSwapRequest.findMany({
        include: {
          requester: { select: { id: true, firstName: true, lastName: true } },
          assignee: { select: { id: true, firstName: true, lastName: true } },
          requesterAssignment: { include: { shift: true } },
          assigneeAssignment: { include: { shift: true } },
          approvedBy: { select: { id: true, firstName: true, lastName: true } },
        },
        orderBy: { createdAt: 'desc' },
      });
    } else {
      // A Manager sees swap requests involving themselves, their direct
      // reports, or where a direct report is on either side of the swap —
      // not every swap request in the company.
      swaps = await prisma.shiftSwapRequest.findMany({
        where: {
          OR: [
            { requesterId: { in: visibleUserIds } },
            { assigneeId: { in: visibleUserIds } },
          ],
        },
        include: {
          requester: { select: { id: true, firstName: true, lastName: true } },
          assignee: { select: { id: true, firstName: true, lastName: true } },
          requesterAssignment: { include: { shift: true } },
          assigneeAssignment: { include: { shift: true } },
          approvedBy: { select: { id: true, firstName: true, lastName: true } },
        },
        orderBy: { createdAt: 'desc' },
      });
    }

    res.status(200).json(swaps);
  } catch (error) {
    next(error);
  }
};

export const updateSwapRequestStatus = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (status !== 'APPROVED' && status !== 'REJECTED') {
      res.status(400).json({ message: 'Status must be APPROVED or REJECTED.' });
      return;
    }

    const swap = await prisma.shiftSwapRequest.findUnique({
      where: { id },
      include: {
        requesterAssignment: true,
        assigneeAssignment: true,
      },
    });

    if (!swap) {
      res.status(404).json({ message: 'Swap request not found.' });
      return;
    }

    if (swap.status !== 'PENDING') {
      res.status(400).json({ message: 'Swap request already processed.' });
      return;
    }

    // Swapping requires Manager approval
    if (!isManagerOrAdmin(req.user?.role!)) {
      res.status(403).json({ message: 'Only managers and admins can approve shift swaps.' });
      return;
    }

    if (swap.requesterId === req.user?.id || swap.assigneeId === req.user?.id) {
      res.status(403).json({ message: 'You cannot approve a shift swap you are personally part of. Ask another manager or admin to review it.' });
      return;
    }

    // A swap touches two employees, so either one being a direct report of the
    // approving manager is enough authority to sign off on it. Admins can always approve.
    const canApproveSwap =
      (await isAuthorizedApprover(req.user!.id, req.user?.role!, swap.requesterId)) ||
      (await isAuthorizedApprover(req.user!.id, req.user?.role!, swap.assigneeId));

    if (!canApproveSwap) {
      res.status(403).json({ message: 'Forbidden. Only the reporting manager of one of these employees, or an admin, can approve this shift swap.' });
      return;
    }

    if (status === 'APPROVED') {
      const requesterShiftId = swap.requesterAssignment.shiftId;
      const assigneeShiftId = swap.assigneeAssignment.shiftId;

      await prisma.$transaction([
        prisma.shiftAssignment.update({
          where: { id: swap.requesterAssignmentId },
          data: { shiftId: assigneeShiftId },
        }),
        prisma.shiftAssignment.update({
          where: { id: swap.assigneeAssignmentId },
          data: { shiftId: requesterShiftId },
        }),
        prisma.shiftSwapRequest.update({
          where: { id },
          data: {
            status: 'APPROVED',
            approvedById: req.user?.id!,
          },
        }),
      ]);
    } else {
      await prisma.shiftSwapRequest.update({
        where: { id },
        data: {
          status: 'REJECTED',
          approvedById: req.user?.id!,
        },
      });
    }

    emitHRUpdate(req, 'SHIFT');
    logAudit(req, 'SHIFT_SWAP_' + status, `${status === 'APPROVED' ? 'Approved' : 'Rejected'} shift swap ${id} between user ${swap.requesterId} and user ${swap.assigneeId}.`);
    res.status(200).json({ message: `Shift swap ${status.toLowerCase()} successfully.` });
  } catch (error) {
    next(error);
  }
};

// ==========================================
// EMPLOYEE RECOGNITION BOARD
// ==========================================

export const getRecognitions = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const recognitions = await prisma.recognition.findMany({
      where: {
        NOT: [
          { message: { contains: 'Happy Birthday' } },
          { message: { contains: 'Work Anniversary' } },
        ]
      },
      include: {
        sender: { select: { id: true, firstName: true, lastName: true, avatarUrl: true, designation: true } },
        receiver: { select: { id: true, firstName: true, lastName: true, avatarUrl: true, designation: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
    res.status(200).json(recognitions);
  } catch (error) {
    next(error);
  }
};

export const getMyWishes = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id!;
    const today = new Date();

    const wishes = await prisma.recognition.findMany({
      where: {
        receiverId: userId,
        OR: [
          { message: { contains: 'Happy Birthday' } },
          { message: { contains: 'Work Anniversary' } }
        ]
      },
      include: {
        sender: { select: { id: true, firstName: true, lastName: true, avatarUrl: true, designation: true } }
      }
    });

    const activeWishes: any[] = [];
    const expiredWishIds: string[] = [];

    wishes.forEach(w => {
      const wDate = new Date(w.createdAt);
      const isSameDay = wDate.getDate() === today.getDate() &&
                        wDate.getMonth() === today.getMonth() &&
                        wDate.getFullYear() === today.getFullYear();
      if (isSameDay) {
        activeWishes.push(w);
      } else {
        expiredWishIds.push(w.id);
      }
    });

    if (expiredWishIds.length > 0) {
      await prisma.recognition.deleteMany({
        where: { id: { in: expiredWishIds } }
      });
    }

    res.status(200).json(activeWishes);
  } catch (error) {
    next(error);
  }
};

// Returns ALL birthday/work-anniversary wishes created today, across the whole org
// (not scoped to the requesting user). Used to:
//  - determine whether the current user has already sent a wish to a given teammate today
//  - show the wishes a teammate has already received alongside the "send wish" action
export const getCelebrationWishes = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const wishes = await prisma.recognition.findMany({
      where: {
        OR: [
          { message: { contains: 'Happy Birthday' } },
          { message: { contains: 'Work Anniversary' } }
        ]
      },
      include: {
        sender: { select: { id: true, firstName: true, lastName: true, avatarUrl: true, designation: true } },
        receiver: { select: { id: true, firstName: true, lastName: true, avatarUrl: true, designation: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    const today = new Date();
    const activeWishes = wishes.filter(w => {
      const wDate = new Date(w.createdAt);
      return wDate.getDate() === today.getDate() &&
             wDate.getMonth() === today.getMonth() &&
             wDate.getFullYear() === today.getFullYear();
    });

    res.status(200).json(activeWishes);
  } catch (error) {
    next(error);
  }
};

export const createRecognition = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const senderId = req.user?.id!;
    const { receiverId, badge, message } = req.body;

    if (!receiverId || !badge || !message) {
      res.status(400).json({ message: 'receiverId, badge, and message are required.' });
      return;
    }

    if (senderId === receiverId) {
      res.status(400).json({ message: 'You cannot recognize yourself!' });
      return;
    }

    const receiver = await prisma.user.findUnique({ where: { id: receiverId } });
    if (!receiver) {
      res.status(404).json({ message: 'Receiver user not found.' });
      return;
    }

    const recognition = await prisma.recognition.create({
      data: {
        senderId,
        receiverId,
        badge,
        message,
      },
      include: {
        sender: { select: { id: true, firstName: true, lastName: true, avatarUrl: true } },
        receiver: { select: { id: true, firstName: true, lastName: true, avatarUrl: true } },
      },
    });

    emitHRUpdate(req, 'RECOGNITION');
    res.status(201).json(recognition);
  } catch (error) {
    next(error);
  }
};

// ==========================================
// ADMIN ONLY FULL CONTROL CRUD
// ==========================================

export const deleteLeaveRequest = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const leave = await prisma.leaveRequest.findUnique({ where: { id } });

    if (!leave) {
      res.status(404).json({ message: 'Leave request not found.' });
      return;
    }

    const isAdmin = req.user?.role === 'ADMIN';
    const isOwner = leave.userId === req.user?.id;

    // Admins can delete any leave request. Employees/managers can only cancel their
    // own request, and only while it hasn't been decided on yet.
    if (!isAdmin) {
      if (!isOwner) {
        res.status(403).json({ message: 'You can only cancel your own leave requests.' });
        return;
      }
      if (leave.status !== 'PENDING') {
        res.status(400).json({ message: 'This request has already been processed and can no longer be cancelled. Contact an admin if you need it removed.' });
        return;
      }
    }

    // Approving a leave deducts its day count from the employee's balance
    // (see updateLeaveStatus above). Deleting an approved request — which
    // only an admin can do, e.g. correcting a mistaken approval or removing
    // a record for leave the employee ultimately didn't take — needs to
    // give those days back, or the employee is left permanently short by
    // however many days this request used, with nothing in the UI to
    // reveal why their balance looks wrong.
    if (leave.status === 'APPROVED') {
      const diffTime = Math.abs(leave.endDate.getTime() - leave.startDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
      const year = leave.startDate.getFullYear();

      const balance = await prisma.leaveBalance.findUnique({
        where: { userId_leaveType_year: { userId: leave.userId, leaveType: leave.leaveType, year } },
      });
      if (balance) {
        await prisma.leaveBalance.update({
          where: { id: balance.id },
          data: { used: Math.max(0, balance.used - diffDays) },
        });
      }
    }

    await prisma.leaveRequest.delete({ where: { id } });
    emitHRUpdate(req, 'LEAVE');
    logAudit(req, 'LEAVE_REQUEST_DELETED', `Deleted leave request ${id} (owner: ${leave.userId}, was ${leave.status}).`);
    res.status(200).json({ message: 'Leave request deleted successfully.' });
  } catch (error) {
    next(error);
  }
};

export const updateLeaveBalance = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (req.user?.role !== 'ADMIN') {
      res.status(403).json({ message: 'Forbidden. Only Admins can modify leave balances.' });
      return;
    }
    const { id } = req.params;
    const { total, used } = req.body;
    const updated = await prisma.leaveBalance.update({
      where: { id },
      data: {
        total: total !== undefined ? parseFloat(total) : undefined,
        used: used !== undefined ? parseFloat(used) : undefined,
      }
    });
    emitHRUpdate(req, 'LEAVE');
    logAudit(req, 'LEAVE_BALANCE_ADJUSTED', `Adjusted leave balance ${id}: total=${total ?? 'unchanged'}, used=${used ?? 'unchanged'}.`);
    res.status(200).json(updated);
  } catch (error) {
    next(error);
  }
};

export const updateAttendanceLog = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (req.user?.role !== 'ADMIN') {
      res.status(403).json({ message: 'Forbidden. Only Admins can adjust attendance logs.' });
      return;
    }
    const { id } = req.params;
    const { clockIn, clockOut, status, notes } = req.body;
    const updated = await prisma.attendance.update({
      where: { id },
      data: {
        clockIn: clockIn ? new Date(clockIn) : undefined,
        clockOut: clockOut ? new Date(clockOut) : undefined,
        status,
        notes,
      }
    });
    emitHRUpdate(req, 'ATTENDANCE');
    logAudit(req, 'ATTENDANCE_LOG_ADJUSTED', `Manually adjusted attendance log ${id} (clockIn/clockOut/status/notes).`);
    res.status(200).json(updated);
  } catch (error) {
    next(error);
  }
};

export const deleteAttendanceLog = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (req.user?.role !== 'ADMIN') {
      res.status(403).json({ message: 'Forbidden. Only Admins can delete attendance logs.' });
      return;
    }
    const { id } = req.params;
    await prisma.attendance.delete({ where: { id } });
    emitHRUpdate(req, 'ATTENDANCE');
    logAudit(req, 'ATTENDANCE_LOG_DELETED', `Deleted attendance log ${id}.`);
    res.status(200).json({ message: 'Attendance log deleted successfully.' });
  } catch (error) {
    next(error);
  }
};

export const deleteExpenseClaim = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const claim = await prisma.expenseClaim.findUnique({ where: { id } });

    if (!claim) {
      res.status(404).json({ message: 'Expense claim not found.' });
      return;
    }

    const isAdmin = req.user?.role === 'ADMIN';
    const isOwner = claim.userId === req.user?.id;

    // Admins can delete any expense claim. Employees/managers can only withdraw
    // their own claim, and only while it hasn't been decided on yet.
    if (!isAdmin) {
      if (!isOwner) {
        res.status(403).json({ message: 'You can only withdraw your own expense claims.' });
        return;
      }
      if (claim.status !== 'PENDING') {
        res.status(400).json({ message: 'This claim has already been processed and can no longer be withdrawn. Contact an admin if you need it removed.' });
        return;
      }
    }

    await prisma.expenseClaim.delete({ where: { id } });
    emitHRUpdate(req, 'EXPENSE');
    logAudit(req, 'EXPENSE_CLAIM_DELETED', `Deleted expense claim ${id} (owner: ${claim.userId}, amount: ${claim.amount}, was ${claim.status}).`);
    res.status(200).json({ message: 'Expense claim deleted successfully.' });
  } catch (error) {
    next(error);
  }
};

export const deletePayslip = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (req.user?.role !== 'ADMIN') {
      res.status(403).json({ message: 'Forbidden. Only Admins can delete payslips.' });
      return;
    }
    const { id } = req.params;
    const deletedPayslip = await prisma.payslip.delete({ where: { id } });
    emitHRUpdate(req, 'PAYSLIP');
    logAudit(req, 'PAYSLIP_DELETED', `Deleted payslip ${id} (user: ${deletedPayslip.userId}, ${deletedPayslip.month}/${deletedPayslip.year}, net: ${deletedPayslip.netSalary}).`);
    res.status(200).json({ message: 'Payslip deleted successfully.' });
  } catch (error) {
    next(error);
  }
};

export const deleteShiftAssignment = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (req.user?.role !== 'ADMIN') {
      res.status(403).json({ message: 'Forbidden. Only Admins can delete shift assignments.' });
      return;
    }
    const { id } = req.params;
    await prisma.shiftAssignment.delete({ where: { id } });
    emitHRUpdate(req, 'SHIFT');
    logAudit(req, 'SHIFT_ASSIGNMENT_DELETED', `Deleted shift assignment ${id}.`);
    res.status(200).json({ message: 'Shift assignment deleted successfully.' });
  } catch (error) {
    next(error);
  }
};

export const deleteShift = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (req.user?.role !== 'ADMIN') {
      res.status(403).json({ message: 'Forbidden. Only Admins can delete shifts.' });
      return;
    }
    const { id } = req.params;
    await prisma.shift.delete({ where: { id } });
    emitHRUpdate(req, 'SHIFT');
    logAudit(req, 'SHIFT_TYPE_DELETED', `Deleted shift type ${id}.`);
    res.status(200).json({ message: 'Shift type deleted successfully.' });
  } catch (error) {
    next(error);
  }
};

export const deleteRecognition = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (req.user?.role !== 'ADMIN') {
      res.status(403).json({ message: 'Forbidden. Only Admins can delete recognitions.' });
      return;
    }
    const { id } = req.params;
    await prisma.recognition.delete({ where: { id } });
    emitHRUpdate(req, 'RECOGNITION');
    res.status(200).json({ message: 'Recognition deleted successfully.' });
  } catch (error) {
    next(error);
  }
};

export const getCelebrations = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const currentMonth = new Date().getMonth() + 1; // 1-indexed (Jan = 1, Dec = 12)
    
    const allUsers = await prisma.user.findMany({
      select: {
        id: true,
        firstName: true,
        lastName: true,
        designation: true,
        avatarUrl: true,
        birthday: true,
        createdAt: true
      }
    });

    const birthdays = allUsers.filter(u => {
      if (!u.birthday) return false;
      return (new Date(u.birthday).getMonth() + 1) === currentMonth;
    }).map(u => ({
      id: u.id,
      firstName: u.firstName,
      lastName: u.lastName,
      designation: u.designation,
      avatarUrl: u.avatarUrl,
      date: u.birthday
    }));

    const anniversaries = allUsers.filter(u => {
      return (new Date(u.createdAt).getMonth() + 1) === currentMonth;
    }).map(u => {
      const years = new Date().getFullYear() - new Date(u.createdAt).getFullYear();
      return {
        id: u.id,
        firstName: u.firstName,
        lastName: u.lastName,
        designation: u.designation,
        avatarUrl: u.avatarUrl,
        date: u.createdAt,
        years: years > 0 ? years : 1
      };
    });

    res.status(200).json({ birthdays, anniversaries });
  } catch (error) {
    next(error);
  }
};
